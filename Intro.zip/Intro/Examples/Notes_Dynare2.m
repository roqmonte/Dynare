% execute a Dynare file
clear all;
close all;
% specify parameters
beta =  0.99;
alpha  = 1/3;
sigma  = 1;
sigmae = 0.01;
rho    = 0.9;
delta  = 0.025;
save param_nc alpha beta delta rho sigma sigmae
dynare Notes_Dynare2 noclearall nolog