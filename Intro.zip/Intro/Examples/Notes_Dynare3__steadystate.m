function [ys,check] = Notes_Dynare3__steadystate(ys,exe)

global M_
alpha  = M_.params(1);
beta   = M_.params(2);
delta  = M_.params(3);
rho    = M_.params(4);
sigma  = M_.params(5);
sigmae = M_.params(6);

k = (alpha/(1/beta - (1-delta)))^(1/(1-alpha));
y = k^(alpha);
I = delta*k;
c = y - I;
a = 1;
w = (1-alpha)*k^(alpha);
R = alpha*k^(alpha-1);
r = (1/beta) - 1;

check = 0;

ys = [log(y);
log(I);
log(k);
log(a);
log(c);
log(w);
log(R);
r];